# Operation Iceburg
> Created by Soyvolon for Guide and Avalanche 3

## Contents
- 1 `mission.sqf.txt` for if the `pbo` file on server does not work
- 1 `Operation_Iceburg_Ava_3_FTX.pbo` for upload to the server